# Mi plugin

Plantilla de documentación. Sustituir por un paquete válido para la aplicación de destino antes de venderlo. Este ZIP no es un plugin instalable.

## Instalación
Indicá aplicación, sistema operativo y versión mínima.

## Configuración
Describí acciones y permisos. No incluyas tokens ni credenciales.

## Pruebas
Verificá la instalación, las acciones y la desinstalación.
