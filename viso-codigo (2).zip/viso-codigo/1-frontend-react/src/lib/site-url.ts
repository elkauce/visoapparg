// Las URLs HTTP del backend viven en el dominio .convex.site
export function getSiteUrl(): string {
  const cloudUrl = import.meta.env.VITE_CONVEX_URL ?? "";
  return cloudUrl.replace(".convex.cloud", ".convex.site");
}
